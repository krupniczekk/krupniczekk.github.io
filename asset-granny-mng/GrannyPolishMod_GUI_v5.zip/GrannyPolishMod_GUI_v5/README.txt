GRANNY LEGACY POLISH VOICE TOOL v5
Autor: Krupnik

NOWE:
- Autor w tytule GUI: "Autor: Krupnik".
- Wyszukiwanie po nazwie AudioClip, Path ID, długości, typie przechowywania i źródłowym pliku.
- Wykrywanie oraz eksport AudioClip osadzonych i zewnętrznych (.resS/.resource).
- Opcja UNSAFE: domyślnie wyłączona. Gdy włączona, próbuje podmienić zewnętrzny strumień:
  kopiuje plik towarzyszący, dopisuje nowe audio na końcu kopii i aktualizuje m_Resource
  (m_Source, m_Offset, m_Size) w kopii assetu.
- Podmiana zapisuje nowy asset i nie nadpisuje oryginalnych plików.

INSTALACJA:
1. Python 3.10+ z https://www.python.org/downloads/ (zaznacz Add Python to PATH).
2. Uruchom INSTALL.bat.
3. Uruchom START_GUI.bat.
4. Wybierz sharedassets*.assets. Wyszukaj nazwę lub Path ID.
5. Wybierz własny plik audio i kliknij PODMIEŃ I ZAPISZ KOPIĘ.

OSTRZEŻENIE:
UNSAFE jest eksperymentalne. Nowe nagranie wstawiane do zewnętrznego strumienia może nie
pasować do oczekiwanego kodeka, formatu audio lub sposobu serializacji konkretnej wersji Unity.
Włączaj tę opcję wyłącznie na kopiach gry. Program pyta o potwierdzenie i zapisuje osobne
pliki. Jeśli gra nie uruchomi assetu, usuń zmodyfikowane kopie i przywróć oryginały.
Dla zewnętrznego AudioClip nowy plik jest dopisywany do kopii strumienia, a referencja
AudioClip kierowana na nowy offset i rozmiar. Nie jest to gwarancja kompatybilności.
