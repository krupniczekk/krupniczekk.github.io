@echo off
chcp 65001 >nul
python -m pip install --upgrade pip
python -m pip install UnityPy soundfile
echo.
echo Instalacja zakonczona. Uruchom START_GUI.bat
pause
