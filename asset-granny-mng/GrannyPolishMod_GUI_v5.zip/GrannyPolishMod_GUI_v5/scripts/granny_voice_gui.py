import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import shutil
import UnityPy

try:
    import soundfile as sf
except Exception:
    sf = None


class App:
    def __init__(self, root):
        self.root = root
        root.title("Granny Legacy Polish Voice Tool | Autor: Krupnik")
        root.geometry("1040x690")
        root.minsize(850, 560)
        self.asset_path = None
        self.env = None
        self.rows = []
        self.selected = None
        self.replacement_path = None
        self.unsafe_var = tk.BooleanVar(value=False)

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        main = ttk.Frame(root, padding=14)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="GRANNY LEGACY", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(main, text="POLISH VOICE TOOL  •  Autor: Krupnik",
                  font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 12))

        top = ttk.Frame(main)
        top.pack(fill="x", pady=(0, 10))
        ttk.Button(top, text="Wybierz plik .assets", command=self.choose_asset).pack(side="left")
        self.path_label = tk.StringVar(value="Nie wybrano pliku")
        ttk.Label(top, textvariable=self.path_label).pack(side="left", padx=10, fill="x", expand=True)
        ttk.Button(top, text="Skanuj ponownie", command=self.scan).pack(side="right")

        pane = ttk.Panedwindow(main, orient="horizontal")
        pane.pack(fill="both", expand=True)
        left = ttk.Frame(pane, padding=(0, 0, 10, 0))
        right = ttk.Frame(pane, padding=(10, 0, 0, 0))
        pane.add(left, weight=3)
        pane.add(right, weight=2)

        ttk.Label(left, text="Znalezione AudioClip", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        searchrow = ttk.Frame(left)
        searchrow.pack(fill="x", pady=6)
        ttk.Label(searchrow, text="Szukaj nazwy / Path ID / czasu / storage:").pack(side="left")
        self.search_var = tk.StringVar()
        ttk.Entry(searchrow, textvariable=self.search_var).pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.search_var.trace_add("write", lambda *_: self.apply_filter())

        cols = ("name", "pathid", "length", "storage", "stream")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", height=20)
        for col, label, width in [
            ("name", "Nazwa", 190), ("pathid", "Path ID", 75),
            ("length", "Długość", 85), ("storage", "Storage", 95),
            ("stream", "Plik strumienia", 150)
        ]:
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="w" if col in ("name", "stream") else "center")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        row = ttk.Frame(left)
        row.pack(fill="x", pady=(8, 0))
        ttk.Button(row, text="Eksportuj zaznaczony", command=self.export_selected).pack(side="left")
        ttk.Button(row, text="Eksportuj wszystkie", command=self.export_all).pack(side="left", padx=8)

        ttk.Label(right, text="Wybrany dźwięk", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.details = tk.StringVar(value="Wybierz AudioClip z listy.")
        ttk.Label(right, textvariable=self.details, wraplength=330, justify="left").pack(anchor="w", pady=(8, 14))

        ttk.Label(right, text="Polskie nagranie (WAV/OGG):").pack(anchor="w")
        self.replacement_label = tk.StringVar(value="Nie wybrano nagrania")
        ttk.Label(right, textvariable=self.replacement_label, wraplength=330).pack(anchor="w", pady=5)
        ttk.Button(right, text="Wybierz nagranie", command=self.choose_replacement).pack(anchor="w")

        ttk.Separator(right).pack(fill="x", pady=14)
        ttk.Label(right, text="Opcje zaawansowane", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Checkbutton(right, text="Włącz UNSAFE – pozwól podmieniać zewnętrzne .resS/.resource",
                        variable=self.unsafe_var).pack(anchor="w", pady=6)
        ttk.Label(right, text=(
            "Domyślnie podmiana zewnętrznych strumieni jest zablokowana. "
            "Po włączeniu UNSAFE program dopisze nowe audio do kopii pliku strumienia "
            "i zaktualizuje offset/rozmiar w kopii assetu. Może to być niezgodne z "
            "konkretną wersją Unity lub kodekiem. Zawsze testuj kopie."
        ), wraplength=330, justify="left").pack(anchor="w")

        ttk.Button(right, text="PODMIEŃ I ZAPISZ KOPIĘ", command=self.replace_selected).pack(fill="x", pady=(14, 0))
        ttk.Label(right, text="Autor: Krupnik", font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(12, 0))

        self.status = tk.StringVar(value="Wybierz plik sharedassets*.assets.")
        ttk.Separator(main).pack(fill="x", pady=10)
        ttk.Label(main, textvariable=self.status).pack(anchor="w")

    def status_msg(self, text):
        self.status.set(text)
        self.root.update_idletasks()

    def choose_asset(self):
        p = filedialog.askopenfilename(title="Wybierz Unity .assets",
                                       filetypes=[("Unity assets", "*.assets"), ("All files", "*.*")])
        if p:
            self.asset_path = Path(p)
            self.path_label.set(str(self.asset_path))
            self.scan()

    def get_resource_info(self, clip):
        res = getattr(clip, "m_Resource", None)
        if not res:
            return "", 0, 0
        source = str(getattr(res, "m_Source", "") or "")
        offset = int(getattr(res, "m_Offset", 0) or 0)
        size = int(getattr(res, "m_Size", 0) or 0)
        return source, offset, size

    def scan(self):
        if not self.asset_path:
            messagebox.showwarning("Brak pliku", "Najpierw wybierz plik .assets.")
            return
        self.tree.delete(*self.tree.get_children())
        self.rows = []
        try:
            self.env = UnityPy.load(str(self.asset_path))
            for obj in self.env.objects:
                if obj.type.name != "AudioClip":
                    continue
                try:
                    clip = obj.parse_as_object()
                    name = getattr(clip, "m_Name", "") or f"AudioClip_{obj.path_id}"
                    length = float(getattr(clip, "m_Length", 0) or 0)
                    embedded = bytes(getattr(clip, "m_AudioData", b"") or b"")
                    source, offset, size = self.get_resource_info(clip)
                    storage = "osadzony" if embedded else ("zewnętrzny" if source and size else "nieznany")
                    row = dict(obj=obj, clip=clip, name=name, pathid=obj.path_id,
                               length=length, storage=storage, source=source,
                               offset=offset, size=size)
                    self.rows.append(row)
                except Exception:
                    continue
            self.apply_filter()
            self.status_msg(f"Znaleziono AudioClip: {len(self.rows)}")
        except Exception as e:
            messagebox.showerror("Błąd skanowania", str(e))
            self.status_msg("Skanowanie nieudane.")

    def apply_filter(self):
        if not hasattr(self, "tree"):
            return
        q = self.search_var.get().strip().lower()
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(self.rows):
            text = f"{r['name']} {r['pathid']} {r['length']} {r['storage']} {r['source']}".lower()
            if not q or q in text:
                self.tree.insert("", "end", iid=str(i),
                    values=(r["name"], r["pathid"], f"{r['length']:.2f}s", r["storage"],
                            Path(r["source"]).name if r["source"] else "—"))

    def on_select(self, _=None):
        sel = self.tree.selection()
        if not sel:
            self.selected = None
            return
        r = self.rows[int(sel[0])]
        self.selected = r
        self.details.set(
            f"Nazwa: {r['name']}\\nPath ID: {r['pathid']}\\nDługość: {r['length']:.3f}s\\n"
            f"Storage: {r['storage']}\\nŹródło: {r['source'] or '—'}\\n"
            f"Offset: {r['offset']}\\nRozmiar: {r['size']}"
        )

    def stream_path(self, row):
        source = row["source"].replace("\\\\", "/")
        basename = Path(source).name
        candidates = [self.asset_path.parent / source, self.asset_path.parent / basename]
        return next((p for p in candidates if p.is_file()), None)

    def export_row(self, row, folder):
        folder.mkdir(parents=True, exist_ok=True)
        samples = row["clip"].samples
        if samples:
            out = []
            for name, data in samples.items():
                suffix = Path(str(name)).suffix or ".audio"
                target = folder / f"{row['name']}_PathID_{row['pathid']}{suffix}"
                target.write_bytes(data)
                out.append(target)
            return out
        if row["storage"] == "zewnętrzny":
            stream = self.stream_path(row)
            if not stream:
                raise RuntimeError(f"Nie znaleziono strumienia: {row['source']}")
            with stream.open("rb") as f:
                f.seek(row["offset"])
                data = f.read(row["size"])
            if not data:
                raise RuntimeError("Strumień zwrócił pusty zakres.")
            ext = ".ogg" if data.startswith(b"OggS") else ".wav" if data.startswith(b"RIFF") else ".bin"
            target = folder / f"{row['name']}_PathID_{row['pathid']}{ext}"
            target.write_bytes(data)
            return [target]
        raise RuntimeError("Brak dostępnych danych audio do eksportu.")

    def export_selected(self):
        if not self.selected:
            messagebox.showinfo("Wybierz AudioClip", "Zaznacz pozycję na liście.")
            return
        folder = filedialog.askdirectory(title="Folder eksportu")
        if not folder:
            return
        try:
            files = self.export_row(self.selected, Path(folder))
            messagebox.showinfo("Eksport", "\\n".join(str(p) for p in files))
        except Exception as e:
            messagebox.showerror("Eksport nieudany", str(e))

    def export_all(self):
        if not self.rows:
            return
        folder = filedialog.askdirectory(title="Folder eksportu wszystkich dźwięków")
        if not folder:
            return
        ok, errors = 0, []
        for r in self.rows:
            try:
                self.export_row(r, Path(folder))
                ok += 1
            except Exception as e:
                errors.append(f"{r['name']} [{r['pathid']}]: {e}")
        messagebox.showinfo("Eksport", f"Wyeksportowano: {ok}\\nBłędy: {len(errors)}\\n" + "\\n".join(errors[:8]))

    def choose_replacement(self):
        p = filedialog.askopenfilename(title="Wybierz polskie audio",
            filetypes=[("Audio", "*.ogg *.wav"), ("OGG", "*.ogg"), ("WAV", "*.wav")])
        if p:
            self.replacement_path = Path(p)
            self.replacement_label.set(str(self.replacement_path))

    def replace_selected(self):
        r = self.selected
        if not r:
            messagebox.showwarning("Brak wyboru", "Zaznacz AudioClip.")
            return
        if not self.replacement_path or not self.replacement_path.is_file():
            messagebox.showwarning("Brak nagrania", "Wybierz plik WAV lub OGG.")
            return
        if sf is None:
            messagebox.showerror("Brak soundfile", "Uruchom INSTALL.bat.")
            return
        try:
            info = sf.info(str(self.replacement_path))
        except Exception as e:
            messagebox.showerror("Nie można odczytać audio", str(e))
            return

        embedded = bytes(getattr(r["clip"], "m_AudioData", b"") or b"")
        external = r["storage"] == "zewnętrzny"
        if external and not self.unsafe_var.get():
            messagebox.showwarning("UNSAFE wyłączone",
                "To AudioClip używa zewnętrznego strumienia. Włącz opcję UNSAFE w panelu po prawej, "
                "jeśli świadomie akceptujesz ryzyko. Domyślnie nic nie zostanie zmienione.")
            return
        if not embedded and not external:
            messagebox.showerror("Nieobsługiwany AudioClip", "Nie znaleziono danych osadzonych ani zewnętrznego strumienia.")
            return
        if external:
            stream = self.stream_path(r)
            if not stream:
                messagebox.showerror("Brak pliku strumienia",
                    f"Nie znaleziono {r['source']} obok pliku .assets. Skopiuj plik .resS/.resource do tego samego folderu.")
                return
            warning = ("UNSAFE: program dopisze nowe audio na koniec kopii strumienia i zmieni offset/rozmiar "
                       "AudioClip. To może nie zadziałać z każdym buildem Unity/kodekiem. "
                       "Zapisze kopię .assets i kopię pliku strumienia; oryginały pozostaną nietknięte.")
            if not messagebox.askyesno("Potwierdź UNSAFE", warning + "\\n\\nKontynuować?"):
                return
        else:
            old = "ogg" if embedded.startswith(b"OggS") else "wav" if embedded.startswith(b"RIFF") else "unknown"
            new = self.replacement_path.suffix.lower().lstrip(".")
            if old != new or old == "unknown":
                messagebox.showerror("Niezgodny format",
                    f"Oryginalny kontener: {old}; nowy plik: {new}. Użyj takiego samego kontenera.")
                return

        out_asset = filedialog.asksaveasfilename(title="Zapisz zmodyfikowany asset",
            initialfile=f"{self.asset_path.stem}_KRUPNIK{self.asset_path.suffix}",
            defaultextension=self.asset_path.suffix,
            filetypes=[("Unity assets", "*.assets"), ("All files", "*.*")])
        if not out_asset:
            return
        out_asset = Path(out_asset)
        out_stream = None

        try:
            clip = r["clip"]
            new_data = self.replacement_path.read_bytes()
            if external:
                # Duplicate the companion stream next to the output asset; append replacement bytes.
                out_stream = out_asset.parent / Path(r["source"]).name
                if out_stream.resolve() == self.stream_path(r).resolve():
                    out_stream = out_asset.parent / (self.stream_path(r).stem + "_KRUPNIK" + self.stream_path(r).suffix)
                shutil.copy2(self.stream_path(r), out_stream)
                with out_stream.open("ab") as f:
                    f.seek(0, 2)
                    new_offset = f.tell()
                    f.write(new_data)
                res = getattr(clip, "m_Resource", None)
                if res is None:
                    raise RuntimeError("UnityPy nie udostępnił m_Resource dla tego AudioClip.")
                res.m_Source = out_stream.name
                res.m_Offset = int(new_offset)
                res.m_Size = int(len(new_data))
                # Keep the clip external; do not put bytes into m_AudioData.
            else:
                clip.m_AudioData = new_data

            if hasattr(clip, "m_Length"):
                clip.m_Length = float(info.duration)
            if hasattr(clip, "m_Channels"):
                clip.m_Channels = int(info.channels)
            if hasattr(clip, "m_Frequency"):
                clip.m_Frequency = int(info.samplerate)
            if hasattr(clip, "m_Samples"):
                clip.m_Samples = int(info.frames)

            r["obj"].patch(clip)
            saved = self.env.file.save()
            out_asset.write_bytes(saved)
            messagebox.showinfo("Zapisano",
                f"Zapisano asset: {out_asset}\\n" +
                (f"Zapisano strumień: {out_stream}\\n" if out_stream else "") +
                "Oryginalne pliki nie zostały nadpisane. Przetestuj kopię gry.")
            self.status_msg(f"Zapisano kopię: {out_asset.name}")
        except Exception as e:
            messagebox.showerror("Podmiana nieudana", f"{e}\\n\\nJeśli utworzono kopię strumienia, usuń ją. Oryginały pozostają nietknięte.")
            self.status_msg("Podmiana nieudana.")


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
