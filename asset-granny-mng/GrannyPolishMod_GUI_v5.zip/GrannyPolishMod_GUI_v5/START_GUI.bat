@echo off
chcp 65001 >nul
python scripts\granny_voice_gui.py
if errorlevel 1 pause
